// $(function(){
//     $('.selectpicker').selectpicker();
// });

$('.moreless-button').click(function() {
    $('.moretext').slideToggle();
    if ($('.moreless-button').text() == "Развернуть") {
        $(this).text("Повернуть");
        $('.more-less-arrow').addClass('rotate')
    } else {
        $(this).text("Развернуть");
        $('.more-less-arrow').removeClass('rotate')
    }
});

$('.tab').on('click', function(evt) {
    evt.preventDefault();
    $(this).addClass('active');
    var sel = this.getAttribute('data-toggle-target');
    $('.tab-content').removeClass('active').filter(sel).addClass('active');
});

$('.banner-slider').slick({
    dots:true,
    prevArrow:"<img class='a-left control-c prev slick-prev' src='./assets/img/arrow-left.png'>",
    nextArrow:"<img class='a-right control-c next slick-next' src='./assets/img/arrow-right.png'>"
});



$('.slider').slick({
    infinite: true,
    slidesToShow: 4,
    slidesToScroll: 1,
    prevArrow:"<div class='slick-left-arrow'><img class='a-left control-c arrow prev slick-prev' src='../../assets/img/arrow.png'></div>",
    nextArrow:"<div class='slick-right-arrow'><img class='a-right control-c arrow next slick-next' src='../../assets/img/arrow.png''></div>"
});


$('.brand-slider').slick({
    infinite: true,
    slidesToShow: 4,
    slidesToScroll: 1,
    prevArrow:"<div class='slick-left-arrow'><img class='a-left control-c arrow prev slick-prev' src='../../assets/img/arrow.png'></div>",
    nextArrow:"<div class='slick-right-arrow'><img class='a-right control-c arrow next slick-next' src='../../assets/img/arrow.png''></div>"
});




$('.single-blog-slider').slick({
    infinite: true,
    slidesToShow: 3,
    slidesToScroll: 1,
    dots:true,
    prevArrow:"<div class='slick-left-arrow'><img class='a-left control-c arrow prev slick-prev' src='../../assets/img/arrow.png'></div>",
    nextArrow:"<div class='slick-right-arrow'><img class='a-right control-c arrow next slick-next' src='../../assets/img/arrow.png''></div>"
});


$('.fix-category-slider').slick({
    infinite: true,
    slidesToShow: 3,
    slidesToScroll: 1,
    prevArrow:"<div class='slick-left-arrow'><img class='a-left control-c arrow prev slick-prev' src='../../assets/img/arrow.png'></div>",
    nextArrow:"<div class='slick-right-arrow'><img class='a-right control-c arrow next slick-next' src='../../assets/img/arrow.png''></div>"
});

$( document ).ready(function() {
   $('.dropdown-toggle').click(function (){
        $('.drop-down-content').slideToggle()
   })
})



$('.slider-for').slick({
    slidesToShow: 1,
    slidesToScroll: 1,
    fade: true,
    asNavFor: '.slider-nav'
});
$('.slider-nav').slick({
    slidesToShow: 3,
    slidesToScroll: 1,
    asNavFor: '.slider-for',
    centerMode: true,
    focusOnSelect: true,
    arrows:false
});


$('.fav-prod-slider').slick({
    infinite: true,
    slidesToShow: 1,
    slidesToScroll: 1,
    dots:true,
    arrows:false,
    prevArrow:"<div class='slick-left-arrow'><img class='a-left control-c arrow prev slick-prev' src='../../assets/img/arrow.png'></div>",
    nextArrow:"<div class='slick-right-arrow'><img class='a-right control-c arrow next slick-next' src='../../assets/img/arrow.png''></div>"
});


$('.slider-audio').slick({
    infinite: true,
    slidesToShow: 3,
    slidesToScroll: 1,
    prevArrow:"<div class='slick-left-arrow'><img class='a-left control-c arrow prev slick-prev' src='../../assets/img/arrow.png'></div>",
    nextArrow:"<div class='slick-right-arrow'><img class='a-right control-c arrow next slick-next' src='../../assets/img/arrow.png''></div>",
});

function openTab(evt, cityName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(cityName).style.display = "block";
    evt.currentTarget.className += " active";
}



let curr_lang = document.querySelector('.current-lang');
let choose_lang = document.querySelector('.choose-lang');

curr_lang.addEventListener('click',()=> {
    this.classList.add('rotate-img');
})



$(document).ready(()=> {
    $('.current-lang').click(()=> {
        $('.choose-lang').slideToggle()
    })
})

const tabsbtn = document.querySelectorAll(".tabs_nav_btn");
const tabsItems = document.querySelectorAll(".tabs_item")

tabsbtn.forEach( function(item) {
    item.addEventListener("click",function() {
        let currentBtn = item;
        let tabId = currentBtn.getAttribute("data-tab");
        let currentTab = document.querySelector(tabId);


        tabsbtn.forEach(function(item) {
            item.classList.remove("active")
        });
        tabsItems.forEach(function(item) {
            item.classList.remove("active");
        })
        currentBtn.classList.add("active");
        currentTab.classList.add("active")
    })
});

const btns_receive = document.querySelectorAll(".btn_how_to_receive");
const tabs_receive = document.querySelectorAll(".content_how_to_receive")

btns_receive.forEach( function(item) {
    item.addEventListener("click",function() {
        let currentBtn = item;
        let tabId = currentBtn.getAttribute("data-tab");
        let currentTab = document.querySelector(tabId);


        btns_receive.forEach(function(item) {
            item.classList.remove("active")
        });
        tabs_receive.forEach(function(item) {
            item.classList.remove("active");
        })
        currentBtn.classList.add("active");
        currentTab.classList.add("active")
    })
});

const btns_payment_method  = document.querySelectorAll(".btn_payment_method");
const contents_payment_method = document.querySelectorAll(".content_payment_method")

btns_payment_method .forEach( function(item) {
    item.addEventListener("click",function() {
        let currentBtn = item;
        let tabId = currentBtn.getAttribute("data-tab");
        let currentTab = document.querySelector(tabId);


        btns_payment_method .forEach(function(item) {
            item.classList.remove("active")
        });
        contents_payment_method.forEach(function(item) {
            item.classList.remove("active");
        })
        currentBtn.classList.add("active");
        currentTab.classList.add("active")
    })
});

const loan_terms = document.querySelectorAll(".loan_term");
loan_terms.forEach( (item) =>  {
    item.addEventListener("click",  function () {
        loan_terms.forEach((item) => {
            item.classList.remove("active")
        })
        item.classList.add("active");
    });
})

const Show_all_cast = document.querySelector(".Show_all_cast");
const continuation_context = document.getElementById("continuation_context");

// Show_all_cast.addEventListener("click",() => {
//     toggle_show()
// })

function toggle_show() {
    continuation_context.classList.toggle("toggle")
}


// comparisons
let acc = document.getElementsByClassName("accordion");
let i;
for (i = 0; i < acc.length; i++) {
    acc[i].addEventListener("click", function () {
        this.classList.toggle("active");
        let panel = this.nextElementSibling;
        if (panel.style.maxHeight) {
            panel.style.maxHeight = null;
        } else {
            panel.style.maxHeight = panel.scrollHeight + "px";
        }
    });
}



//basket
$(".slider-tabs").slick({
    infinite: true,
    slidesToShow: 5,
    slidesToScroll: 1,
    prevArrow:
        "<div class='slick-left-arrow-bug slick-left-arrow'><img class='a-left control-c arrow prev slick-prev' src='../../assets/img/arrow.png'></div>",
    nextArrow:
        "<div class='slick-right-arrow-bug slick-right-arrow'><img class='a-right control-c arrow next slick-next' src='../../assets/img/arrow.png''></div>",
});
$(".slider-bug").slick({
    infinite: true,
    slidesToShow: 6,
    slidesToScroll: 1,
    prevArrow:
        "<div class='slick-left-arrow'><img class='a-left control-c arrow prev slick-prev' src='../../assets/img/arrow.png'></div>",
    nextArrow:
        "<div class='slick-right-arrow'><img class='a-right control-c arrow next slick-next' src='../../assets/img/arrow.png''></div>",
});

